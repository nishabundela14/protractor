function add(a, b) {
    return a + b;
}

describe("Hello test", function(){
    beforeEach(function(){
        console.log("before each 1");
    })

    beforeEach(function(){
        console.log("before each 2");
    })  

    it("1+ 2", function() {
        expect(1 + 2).toBe(3);
    })

    
    it("2+ 2", function() {
        expect(add(1,2)).toBe(3);
    })
})