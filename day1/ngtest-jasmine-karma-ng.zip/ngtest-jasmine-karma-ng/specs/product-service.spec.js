describe("testing product service ", function(){

    beforeEach(module("productApp"));

    var productService;
    beforeEach(inject(function(_productService_){
        productService = _productService_;
    }))

    beforeEach(inject(function($injector){
        productService = $injector.get("productService");
    }))

    it ("get products length test", function(){
        var contacts = productService.getProducts();
        expect(contacts.length).toBe(5);
    })
})