describe("inject into app", function() {
        
    beforeEach(module('productApp', function ($provide) {
        $provide.value('apiEndPoint', "http://test.com");

        var psMock = {
            getProducts : function() {
                console.log("called mock getProducts");

                return []
            }
        }

        $provide.value("productService", psMock);
    }));

    
    var endPoint;

    beforeEach(inject(function(apiEndPoint){
        endPoint = apiEndPoint;
    }))

    var productService;
    beforeEach(inject(function(_productService_){
        productService = _productService_;
    }))

      
    it("test api end point", function() {
        expect(endPoint).toBe("http://test.com")
    })

    it ("get products length test", function(){
        var products = productService.getProducts();
        expect(products.length).toBe(0);
    })




})