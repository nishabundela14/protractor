describe("App Config Test", function(){
    beforeEach(module("productApp"));
    
    var endPoint;

    beforeEach(inject(function(apiEndPoint){
        endPoint = apiEndPoint;
    }))
      
    it("test api end point", function() {
        expect(endPoint).toBe("example.com")
    })

});