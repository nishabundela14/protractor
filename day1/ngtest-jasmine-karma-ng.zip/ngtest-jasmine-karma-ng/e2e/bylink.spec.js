describe("app title test", function(){
    it("test app title", function() {
        browser.get("http://localhost:8080/");

        browser.sleep(5000);

        var i = 0;

        i++;
        console.log(i);

        element(by.linkText("Brands")).click();
        
        browser.sleep(5000);

        expect(browser.getTitle()).toContain("Brands");
    })

    
})