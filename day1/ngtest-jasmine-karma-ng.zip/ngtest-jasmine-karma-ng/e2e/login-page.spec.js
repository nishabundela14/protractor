xdescribe("invalid login", function() {
    it("invalid username", function(){
        browser.get("http://localhost:8080/#/auth/login");

        browser.sleep(3000);

        element(by.model("username")).sendKeys("admin");
        element(by.model("password")).sendKeys("admin");

        element(by.id("login")).click();

        browser.sleep(4000);

        expect(browser.getTitle()).toBe("Product App-Home");
    })
})