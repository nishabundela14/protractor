describe("app title test", function(){
    xit("test app title", function() {
        browser.get("http://localhost:8080/");

        browser.sleep(5000);

        expect(browser.getTitle()).toBe("Product App-");
    }).pend('want to save time');
})
