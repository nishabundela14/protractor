var math = require("./math");

console.log("hello-world");

console.log(math.add(10, 20));