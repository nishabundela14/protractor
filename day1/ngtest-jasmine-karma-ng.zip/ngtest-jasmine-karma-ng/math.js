//common.js export

module.exports = {
    add: function(a, b) {
        return a + b;
    }
}
