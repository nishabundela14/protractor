angular.module("productApp", [
    "app.controllers",
    "app.services"
])

.value("apiEndPoint", "example.com")

.run(function($rootScope, apiEndPoint){
    console.log("run ", apiEndPoint);

    $rootScope.greeting = "Hello Angular";
})

.run(function($injector){
    console.log("injector ", $injector.get("productService"))
})