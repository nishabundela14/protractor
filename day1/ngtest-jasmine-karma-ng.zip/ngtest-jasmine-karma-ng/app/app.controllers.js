angular.module("app.controllers", [])

.controller("ContactController", function(contactService, $scope){
    console.log("ContactController created");

    $scope.title = "Contacts Page";
    $scope.pageName = "My contacts page";
    $scope.memberName = "Member";

    $scope.members = [
        "Krish",
        "Nila",
        "Asok"
    ]

    $scope.contacts = contactService.getContacts();

    $scope.addNewMember = function() {

        console.log($scope.memberName);
        $scope.members.push($scope.memberName);
    }
})

.controller("AboutController", function($scope){

})

.controller("ProductListController", function($scope, productService){
    console.log("ProductListController Created");

    $scope.products = productService.getProducts();
})