angular.module("app.services", [])

.service("contactService", function(){
    console.log("contactService created");

    this.getContacts = function() {
        return [
            {city: 'BLR', state: 'KA'},
             {city: 'Mysore', state: 'KA'},
              {city: 'Pune', state: 'MH'}
        ]
    }
})


.service("productService", function(){
    console.log("productService created");

    this.getProducts = function() {
        return [
            {name: 'iPhone 1', year: 2010},
             {name: 'Nexus' , year: 2013},
            {name: 'iPhone 2', year: 2010},
            {name: 'iPhone 3', year: 2011},
            {name: 'MotoG', year: 2012}
           
        ]
    }
})